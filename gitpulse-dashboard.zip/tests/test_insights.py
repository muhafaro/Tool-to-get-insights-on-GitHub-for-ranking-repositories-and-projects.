from app.insights import build_insights, health_score


def repo(**overrides):
    source = {"name": "example", "html_url": "https://github.com/a/example", "description": "A useful project", "license": {"key": "mit"}, "homepage": "https://example.com", "has_pages": False, "topics": ["python"], "updated_at": "2026-10-01T00:00:00Z", "language": "Python", "stargazers_count": 5, "forks_count": 2, "open_issues_count": 1, "archived": False, "fork": False}
    source.update(overrides)
    return source


def test_health_score_rewards_visible_project_quality():
    assert health_score(repo()) > health_score(repo(description=None, license=None, homepage=None, topics=[], updated_at="2020-01-01T00:00:00Z"))


def test_build_insights_aggregates_public_repositories():
    result = build_insights({"login": "a", "html_url": "https://github.com/a", "public_repos": 1, "followers": 0}, [repo()])
    assert result["summary"]["stars"] == 5
    assert result["languages"] == [{"name": "Python", "count": 1}]
    assert result["repositories"][0]["name"] == "example"
