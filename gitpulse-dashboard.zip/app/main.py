import os
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .insights import build_insights

ROOT = Path(__file__).parent
app = FastAPI(title="GitPulse", version="1.0.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "templates")


def github_headers() -> dict:
    headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "GitPulse-dashboard"}
    if token := os.getenv("GITHUB_TOKEN"):
        headers["Authorization"] = f"Bearer {token}"
    return headers


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/api/analyze")
async def analyze(username: str = Query(min_length=1, max_length=39, pattern=r"^[A-Za-z0-9-]+$")):
    base = f"https://api.github.com/users/{username}"
    try:
        async with httpx.AsyncClient(headers=github_headers(), timeout=15) as client:
            profile_response = await client.get(base)
            if profile_response.status_code == 404:
                raise HTTPException(404, "GitHub user not found.")
            if profile_response.status_code == 403:
                raise HTTPException(429, "GitHub API rate limit reached. Set GITHUB_TOKEN and try again.")
            profile_response.raise_for_status()
            repos_response = await client.get(f"{base}/repos", params={"per_page": 100, "sort": "updated", "direction": "desc"})
            repos_response.raise_for_status()
    except httpx.HTTPError as error:
        raise HTTPException(502, "Could not reach the GitHub API. Please try again.") from error
    return build_insights(profile_response.json(), repos_response.json())
