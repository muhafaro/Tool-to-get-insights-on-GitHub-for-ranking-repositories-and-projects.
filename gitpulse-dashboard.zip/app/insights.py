from collections import Counter
from datetime import datetime, timezone


def iso_date(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def health_score(repo: dict, now: datetime | None = None) -> int:
    """Score visible signs of a maintained, well-documented repository."""
    now = now or datetime.now(timezone.utc)
    score = 25 if repo.get("description") else 0
    score += 15 if repo.get("license") else 0
    score += 10 if repo.get("homepage") or repo.get("has_pages") else 0
    score += min(15, len(repo.get("topics", [])) * 3)
    updated = iso_date(repo.get("updated_at"))
    if updated:
        age = (now - updated).days
        score += 35 if age <= 30 else 25 if age <= 180 else 10 if age <= 365 else 0
    return min(100, score)


def build_insights(profile: dict, repositories: list[dict]) -> dict:
    active = [r for r in repositories if not r.get("archived") and not r.get("fork")]
    languages = Counter(r["language"] for r in active if r.get("language"))
    stars = sum(r.get("stargazers_count", 0) for r in active)
    forks = sum(r.get("forks_count", 0) for r in active)
    issues = sum(r.get("open_issues_count", 0) for r in active)
    scored = [{
        "name": r["name"], "url": r["html_url"], "description": r.get("description") or "No description yet.",
        "language": r.get("language") or "Unspecified", "stars": r.get("stargazers_count", 0),
        "forks": r.get("forks_count", 0), "issues": r.get("open_issues_count", 0),
        "updated_at": r.get("updated_at"), "health": health_score(r), "archived": r.get("archived", False),
    } for r in active]
    scored.sort(key=lambda r: (r["health"], r["stars"]), reverse=True)
    strengths, next_steps = [], []
    if any(r.get("license") for r in active): strengths.append("At least one project has a clear open-source license.")
    if any(r.get("homepage") or r.get("has_pages") for r in active): strengths.append("You have projects with a public demo or project site.")
    if len(languages) >= 3: strengths.append("Your work spans multiple programming languages.")
    if not strengths: strengths.append("You have a clean base to turn into a focused, recruiter-friendly portfolio.")
    without_description = sum(not r.get("description") for r in active)
    stale = sum((datetime.now(timezone.utc) - iso_date(r["updated_at"])).days > 365 for r in active if iso_date(r.get("updated_at")))
    if without_description: next_steps.append(f"Add concise descriptions to {without_description} repository{'ies' if without_description != 1 else ''}.")
    if stale: next_steps.append(f"Refresh, archive, or explain {stale} inactive project{'s' if stale != 1 else ''}.")
    if not any(r.get("license") for r in active): next_steps.append("Add a license to the projects you want others to use or review.")
    if not any(r.get("homepage") or r.get("has_pages") for r in active): next_steps.append("Deploy your strongest project and link its live demo in the repository.")
    return {
        "profile": {"login": profile["login"], "name": profile.get("name") or profile["login"], "avatar_url": profile.get("avatar_url"), "html_url": profile["html_url"], "bio": profile.get("bio"), "public_repos": profile.get("public_repos", 0), "followers": profile.get("followers", 0)},
        "summary": {"repositories": len(active), "stars": stars, "forks": forks, "open_issues": issues, "average_health": round(sum(r["health"] for r in scored) / len(scored)) if scored else 0},
        "languages": [{"name": name, "count": count} for name, count in languages.most_common(8)],
        "repositories": scored[:12], "strengths": strengths, "next_steps": next_steps,
    }
