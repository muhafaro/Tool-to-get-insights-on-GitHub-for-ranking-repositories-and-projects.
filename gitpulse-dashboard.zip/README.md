# GitPulse

GitPulse is a polished, local web dashboard that turns a public GitHub profile into actionable portfolio insights. It shows repository health, language breadth, community signals, and practical improvements to make your profile stronger.

## Why this is portfolio-worthy

- A real external API integration with validation, error states, API-version headers, and rate-limit guidance.
- A Python/FastAPI backend rather than exposing a GitHub token in the browser.
- Responsive, dependency-light UI; intentional scoring logic covered by unit tests.
- Reproducible local and Docker setup plus GitHub Actions CI.

## Run locally

Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://localhost:8000 and enter any public GitHub username.

### Optional GitHub token

Unauthenticated GitHub API access is limited. Copy `.env.example` to `.env`, set a fine-grained **read-only** token, then export it before running:

```bash
export GITHUB_TOKEN="your_token_here"
```

Do not add `.env` to Git or put a token in frontend code.

## Run with Docker

```bash
docker compose up --build
```

## Test

```bash
pip install pytest
pytest -q
```

## Repository structure

```text
app/main.py          FastAPI routes and GitHub API client
app/insights.py      Scoring and portfolio guidance logic
app/templates/       Server-rendered shell
app/static/          Responsive UI
tests/               Unit tests
```

## Next improvements

1. Add OAuth and private-repository opt-in analysis.
2. Persist weekly score snapshots in PostgreSQL.
3. Add commit activity, workflow reliability, and README-quality analysis.
4. Deploy it on Render, Fly.io, or a similar host, then add the URL here.
